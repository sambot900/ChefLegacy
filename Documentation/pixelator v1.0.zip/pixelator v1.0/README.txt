pixelator v1.0 READ ME
---------------------
1. Run the provided executable "pixelator v1.0.exe".
2. Input Directory: Provide a directory path or browse to the directory for the images you want to downscale. You can link to directory with multiple images, but be aware that you will be downscaling all images in this directory. This downscaling operating is not destructive because it creates a new output file.
3. Output directory: Provide a directory path or browse to the directory where you want the outputted files to be created.
4. Provide a comma separated list of the different pixel sizes you want (bigger number means larger pixels and therefore less definition in the image). If you provide multiple values, you will generate multiple output images per input image. (2 values in this field will create 2 output images per 1 input image).
	*Example: 4 pictures and 3 pixel size values = 12 output images (4 * 3)
5. Press the "Process" button to generate downscaled images from the input directory to the output directory.
---------------------
INPUT FILE DELETION BUTTON: Goes to recycle bin.
OUTPUT FILE DELETION BUTTON: Permanently deleted.